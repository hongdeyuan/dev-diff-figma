# use

- setting figma token
- setting figma url
- setting app dom selector

# note

- Google Chrome defaults to disabling third-party cookies and requires manual activation
  - macos run: `open -a "Google Chrome" --args --disable-features=SameSiteByDefaultCookies`
